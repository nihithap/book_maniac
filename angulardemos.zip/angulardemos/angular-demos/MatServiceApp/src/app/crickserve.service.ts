import { Injectable } from '@angular/core';

@Injectable(
  {
 providedIn: 'root'
}

)
export class CrickserveService {

  constructor() { 
  }







  
//  validateName(nm : string) : boolean
//  {
//    if(nm.length<5)
//    return false;
//    else
//    return true;
//  }

}
