import { TestBed } from '@angular/core/testing';

import { PlayerservService } from './playerserv.service';

describe('PlayerservService', () => {
  let service: PlayerservService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlayerservService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
