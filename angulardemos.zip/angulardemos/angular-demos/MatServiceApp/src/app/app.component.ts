import { Component } from '@angular/core';
import { CrickserveService } from './crickserve.service';
import { Player } from './player';
import { PlayerservService } from './playerserv.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MatServiceApp';
  msg : string;
  playerobj : Player;
  players : Array<Player> =[];
constructor(private playerserv : PlayerservService) //dependency injection
{
this.playerobj=new Player();
}


ngOnInit():void
{
 // this.getallplayers();
//  console.log(this.players[0].playername);
}

addplayer()
{
  this.players.push(this.playerobj);
 this.playerserv.addPlayerdata(this.playerobj).subscribe(

 
   (plobj)=> 
    {
      console.log("Played added");
     
    })
 ,
 (err)=>
 {
   
     console.log("Error occured" + err);
  

 } ;



} // addplayer()


getallplayers()
{

  this.playerserv.getPlayerDetail().subscribe
  (
    (plaarray)=> {
      
      this.players=plaarray;
      console.log("inside get call" + this.players[0].playername);


    }

   

  );
 // console.log("inside get call" + this.players[0].playername);
}








// evtnamecheck(obj)
// {

//   let name=obj.value;
//  // alert(obj.value);

//   let ans=this.crickservobj.validateName(name);
//   if(ans)
//   this.msg="Valid";
//   else
//    this.msg="Invalid";

// }
}
