import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-grouplogin',
  templateUrl: './grouplogin.component.html',
  styleUrls: ['./grouplogin.component.css']
})
export class GrouploginComponent implements OnInit {

  User : FormGroup;
  username : FormControl;
  password : FormControl;
  constructor() { }

  ngOnInit(): void {

    this.User=new FormGroup(
{
  username : new FormControl('',Validators.required),
  password: new FormControl('',Validators.minLength(5))
}

    );
  }

  store()
  {

console.log(this.User.value);

  }


}
