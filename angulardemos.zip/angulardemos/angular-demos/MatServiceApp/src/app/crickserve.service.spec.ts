import { TestBed } from '@angular/core/testing';

import { CrickserveService } from './crickserve.service';

describe('CrickserveService', () => {
  let service: CrickserveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CrickserveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
