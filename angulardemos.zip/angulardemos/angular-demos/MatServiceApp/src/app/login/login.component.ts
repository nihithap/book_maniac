import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username : FormControl;
  password : FormControl;

  constructor() {

    this.username=new FormControl('',Validators.required);
    this.password=new FormControl('',Validators.minLength(6));
   }

  ngOnInit(): void {
  }

  Store()
  {
    alert(this.username.value); 
    alert(this.password.value);
  }

 checkUsername() : string
 {
   if(this.username.touched && this.username.invalid)
   {
   //  if (this.username.hasError('required'))
     return "Name cant be Null";
     //else
     //return "";
   }
   else
   return "";
 }


}
