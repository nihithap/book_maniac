import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Player } from './player';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PlayerservService {

url: string = 'http://localhost:3000/player';
  player : Player;
players : Array<Player> = [];

  constructor(private httpcli : HttpClient) {

    this.player=new Player();
   }

getPlayerDetail() : Observable<Array<Player>>
{
 return (this.httpcli.get<Array<Player>>(this.url));
}

addPlayerdata(newplayer : Player) : Observable<Player>
{
  return (this.httpcli.post<Player>(this.url,newplayer));
}

}
