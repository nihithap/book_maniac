export class Movie
{
    movieid : number;
    moviename:string;
    lang : string;

    constructor()
    {}
}