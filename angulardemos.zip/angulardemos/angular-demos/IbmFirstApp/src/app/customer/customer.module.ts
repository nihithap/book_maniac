import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewmovieComponent } from './viewmovie/viewmovie.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FooterComponent } from './footer/footer.component';



@NgModule({
  declarations: [ViewmovieComponent, DashboardComponent, FooterComponent],
  exports:[ViewmovieComponent,DashboardComponent],
  imports: [
    CommonModule
  ]
})
export class CustomerModule { }
