import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-viewmovie',
  templateUrl: './viewmovie.component.html',
  styleUrls: ['./viewmovie.component.css']
})
export class ViewmovieComponent implements OnInit {


  @Input()
  mfound : string;
  
  constructor() { }

  ngOnInit(): void {
  }

}
