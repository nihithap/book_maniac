import { Component, OnInit, Input } from '@angular/core';
import { Movie } from '../movie';

@Component({
  selector: 'app-moviemain',
  templateUrl: './moviemain.component.html',
  styleUrls: ['./moviemain.component.css']
})
export class MoviemainComponent implements OnInit {


  @Input()
  mydata : string;

  movieobj : Movie;
  searchname : string;
  moviesarr : Movie[]=new Array(5);
  movieresult : Movie[] = new Array(1);
  msize : number;
  constructor() { 
  
    // this.movieobj.movieid=100;
    // this.movieobj.moviename="Kashmir";
    // this.movieobj.lang="Marathi";

  }

  ngOnInit(): void {

    this.movieobj=new Movie();

    this.msize=0;
  }

   addMovie()
   {
     this.moviesarr.push(this.movieobj);
     
     this.moviesarr.forEach( mov => console.log(mov.moviename));

     this.msize=this.moviesarr.length;

     this.movieobj=new Movie();
     alert("Movie added");
   }
   searchMovie()
   {
     let movname=prompt("Enter moviename");

   this.movieresult=this.moviesarr.filter( mov=>mov.moviename.trim()==movname.trim());

   console.log(this.movieresult[0].movieid);

this.searchname="Found " + this.movieresult[0].moviename;


   }

}
