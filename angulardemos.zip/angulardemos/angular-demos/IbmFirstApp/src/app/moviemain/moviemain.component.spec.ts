import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MoviemainComponent } from './moviemain.component';

describe('MoviemainComponent', () => {
  let component: MoviemainComponent;
  let fixture: ComponentFixture<MoviemainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoviemainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoviemainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
