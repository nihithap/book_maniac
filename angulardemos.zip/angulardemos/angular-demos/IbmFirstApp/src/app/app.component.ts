import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  age : number;
  title = 'IbmFirstApp';
  mycolor:string;
  myflag:boolean;

constructor()
{
  this.age=16;
  this.mycolor="red";
  this.myflag=true;
}
 
 displayMsg()
 {
   alert("Hai Welcome");
 }




}
