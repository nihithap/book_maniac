import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { PlayerService } from '../player.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  msg : string;
  playerobj : Player;
  players : Array<Player> =[];
constructor(private playerserv : PlayerService) //dependency injection
{
this.playerobj=new Player();
}


ngOnInit():void
{
  this.getallplayers();
//  console.log(this.players[0].playername);
}

addplayer()
{
  this.players.push(this.playerobj);
 this.playerserv.addPlayerdata(this.playerobj).subscribe(
   (plobj)=> 
    {
      console.log("Played added" + plobj.playername);
     
    }
 ,
 (err)=>
 {
   
     console.log("Error occured" + err);
  

 }) ;

this.playerobj=new Player();

} // addplayer()


getallplayers()
{

  this.playerserv.getPlayerDetail().subscribe
  (
    (plaarray)=> {
      
      this.players=plaarray;
     // console.log("inside get call" + this.players[0].playername);
    }
  );
}







}
