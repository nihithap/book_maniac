import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { AuthenticateService } from '../authenticate.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username : FormControl;
  password : FormControl;
  ibmtoken : string;
  msg :string;
  constructor(private authservice : AuthenticateService,private routeserve : MyrouteService) {

    this.username=new FormControl('',Validators.required);
    this.password=new FormControl('',Validators.minLength(6));
   }

  ngOnInit(): void {
  }

  loginData()
  {
   let data={
     username : this.username.value,
     password:this.password.value
   }

   if (this.username.valid)
   {
    this.authservice.authenticateUser(data).subscribe
    (
     (res)=>{
        this.ibmtoken=res['token'];
        this.authservice.setbearerToken(this.ibmtoken);
        this.routeserve.routeToDashboard();
        console.log(this.ibmtoken);
     },
     (err) =>{
          if(err.status==403)
        this.msg=err.message;

     }


    ) // subscribe
    } //if



   } //method


  

 checkUsername() : string
 {
   if(this.username.touched && this.username.invalid)
   {
   //  if (this.username.hasError('required'))
     return "Name cant be Null";
     //else
     //return "";
   }
   else
   return "";
 }
}
