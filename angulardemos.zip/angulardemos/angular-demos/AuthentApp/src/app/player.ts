export class Player
{
    id : number;
    playername : string;
    country : string;
    constructor()
    {

    }
}