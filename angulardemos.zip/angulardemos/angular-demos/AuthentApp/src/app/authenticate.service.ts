import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

   url :string;
  constructor(private httpclient : HttpClient) { 

    this.url='http://localhost:3000/auth/v1/';
  }

  authenticateUser(data)
  {
    return this.httpclient.post(this.url,data);
  }

  setbearerToken(tok)
  {
    sessionStorage.setItem("mytoken",tok);
  }

  getbearerToken()
  {
    return sessionStorage.getItem("mytoken");
  }

  istokenAuthorized(tok) : Promise<boolean>
  {

return this.httpclient.post(`${this.url}isAuthenticated`,{},
 {
headers : new HttpHeaders().set('Authorization',`Bearer ${tok}`)
 }
 ).map(
   (res) => { return (res['isAuthenticated']);}).toPromise();
 

  }


}
