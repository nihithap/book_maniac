import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Player } from './player';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticateService } from './authenticate.service';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

player : Player;
players : Array<Player>=[];

constructor(private httpclient : HttpClient,private authservice : AuthenticateService)
{
this.player=new Player();

}

  addPlayerdata(playerobj : Player) : Observable<Player>
  {
    let tok=this.authservice.getbearerToken();
 return this.httpclient.post<Player>('http://localhost:3000/api/v1/players',playerobj,
 {
  headers : new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
 )

  }

  getPlayerDetail() : Observable<Array<Player>>
  {
    let tok=this.authservice.getbearerToken();
return this.httpclient.get<Array<Player>>('http://localhost:3000/api/v1/players',
{
  headers : new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
)
  }

  
}
