import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {Location} from '@angular/common';
@Injectable({
  providedIn: 'root'
})
export class MyrouteService {

  constructor(private routeobj: Router,private loca : Location) { }

  openDashboard()
  {
    this.routeobj.navigate(['dashboard']);
  }

openHome()
{
  this.routeobj.navigate(['home']);

}
openAbout()
{
  this.routeobj.navigate(['about']);
}

openLogin()
{
  this.routeobj.navigate(['login'])
}
openTraining()
{
  this.routeobj.navigate(['dashboard/viewtrain']);
}

openProduct()
{
  this.routeobj.navigate(['dashboard/viewproduct']);
}
goBack()
{
  this.loca.back();
}

}
