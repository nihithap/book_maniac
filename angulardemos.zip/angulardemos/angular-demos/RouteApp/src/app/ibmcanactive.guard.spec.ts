import { TestBed } from '@angular/core/testing';

import { IbmcanactiveGuard } from './ibmcanactive.guard';

describe('IbmcanactiveGuard', () => {
  let guard: IbmcanactiveGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(IbmcanactiveGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
