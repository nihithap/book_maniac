import { Component, OnInit } from '@angular/core';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private routeserve : MyrouteService) { }

  ngOnInit(): void {
  }

  login(uname)
  {
    sessionStorage.setItem("username",uname);
  this.routeserve.openDashboard();
  }
}
