import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewtrainingsComponent } from './viewtrainings.component';

describe('ViewtrainingsComponent', () => {
  let component: ViewtrainingsComponent;
  let fixture: ComponentFixture<ViewtrainingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewtrainingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewtrainingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
