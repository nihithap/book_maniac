import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewtrainings',
  templateUrl: './viewtrainings.component.html',
  styleUrls: ['./viewtrainings.component.css']
})
export class ViewtrainingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
