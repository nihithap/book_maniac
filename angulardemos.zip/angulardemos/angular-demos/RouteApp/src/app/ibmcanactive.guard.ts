import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { MyrouteService } from './myroute.service';

@Injectable({
  providedIn: 'root'
})
export class IbmcanactiveGuard implements CanActivate {


  constructor(private myroute : MyrouteService)
  {

  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
 
 let uname=sessionStorage.getItem("username");
 if((uname=="") || (uname==null))
 {
     this.myroute.openLogin();  
     return false;
 }
else
      return true;

  }
  
}
