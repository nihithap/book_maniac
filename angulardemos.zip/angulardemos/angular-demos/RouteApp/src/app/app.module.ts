import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import {Routes,RouterModule} from '@angular/router';
import { ViewtrainingsComponent } from './viewtrainings/viewtrainings.component';
import { ViewproductsComponent } from './viewproducts/viewproducts.component';
import { IbmcanactiveGuard } from './ibmcanactive.guard';

const myroute : Routes = [

  {
  path:'home',
  component:HomeComponent
  },
  {
path:'about',
component:AboutComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'dashboard',
    component:DashboardComponent,
    canActivate:[IbmcanactiveGuard],
    children:
    [
    {
      path:'viewtrain',
      component:ViewtrainingsComponent
    },
    {
      path:"viewproduct",
      component:ViewproductsComponent
    },
    
    {path:'',
    redirectTo:'viewtrain',
    pathMatch:'full'
  }

  ]
  },
  {
    path:'',
    redirectTo:'home',
    pathMatch:'full'
  }

]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    AboutComponent,
    DashboardComponent,
    LoginComponent,
    ViewtrainingsComponent,
    ViewproductsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(myroute)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
