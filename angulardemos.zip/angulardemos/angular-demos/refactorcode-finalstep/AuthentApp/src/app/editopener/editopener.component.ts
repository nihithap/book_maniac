import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DialogcardComponent } from '../dialogcard/dialogcard.component';

@Component({
  selector: 'app-editopener',
  templateUrl: './editopener.component.html',
  styleUrls: ['./editopener.component.css']
})
export class EditopenerComponent implements OnInit {

  constructor(private actroute : ActivatedRoute,private mydialog : MatDialog) { 

    const playid= +this.actroute.snapshot.paramMap.get('playerparam');
    console.log(playid);
  const dialogobj= this.mydialog.open(DialogcardComponent,{
      data:{playerid:playid}
    }) 

  }

  ngOnInit(): void {
  }

}
