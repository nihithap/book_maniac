import { Component, OnInit } from '@angular/core';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  flag : boolean =true;
  constructor(private route : MyrouteService) { }

  ngOnInit(): void {
  }


  showview()
  {
    if(this.flag==true)
    {
    this.route.routeToGridview()
      this.flag=false;
    }
    else
    {
      this.route.routeToListview();
      this.flag=true;
    }

  }
}
