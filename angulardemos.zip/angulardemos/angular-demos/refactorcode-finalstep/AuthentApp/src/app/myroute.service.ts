import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {Location} from '@angular/common'
@Injectable({
  providedIn: 'root'
})
export class MyrouteService {

  constructor(private router : Router,private loca : Location) { }

  routeToDashboard()
  {
    this.router.navigate(['dashboard']);
  }

  routeToLogin()
  {
    this.router.navigate(['login']);
  }

  routeToListview()
  {
    this.router.navigate(['dashboard/listview']);
  }
  routeToGridview()
  {
    this.router.navigate(['dashboard/gridview']);
  }

  routeToEditOpener(playerid)
  {
    this.router.navigate(['dashboard', 
    {outlets:{playerEditoutlet:['player',playerid,'edit']}    }])
  }
   
  routeback()
  {
  this.loca.back();
  }
}
