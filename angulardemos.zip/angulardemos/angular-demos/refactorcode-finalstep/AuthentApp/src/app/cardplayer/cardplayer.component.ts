import { Component, OnInit, Input } from '@angular/core';
import { Player } from '../player';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-cardplayer',
  templateUrl: './cardplayer.component.html',
  styleUrls: ['./cardplayer.component.css']
})
export class CardplayerComponent implements OnInit {

  @Input()
  playerinfo : Player;
  
  constructor(private myroute : MyrouteService) { }

  ngOnInit(): void {
  }
    openEditview()
    {
     this.myroute.routeToEditOpener(this.playerinfo.id);
    }
}
