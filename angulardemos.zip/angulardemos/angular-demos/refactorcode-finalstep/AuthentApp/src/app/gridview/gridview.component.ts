import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { PlayerService } from '../player.service';

@Component({
  selector: 'app-gridview',
  templateUrl: './gridview.component.html',
  styleUrls: ['./gridview.component.css']
})
export class GridviewComponent implements OnInit {

  msg : string;
  playerobj : Player;
  players : Array<Player> =[];
constructor(private playerserv : PlayerService) //dependency injection
{
this.playerobj=new Player();
}


ngOnInit():void
{
  this.getallplayers();
 
}

  getallplayers()
{

  this.playerserv.getPlayerDetail().subscribe
  (
    (plaarray)=> {
      
      this.players=plaarray;
     // console.log("inside get call" + this.players[0].playername);
    }
  );
}

}
