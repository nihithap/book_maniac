import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayertakerComponent } from './playertaker.component';

describe('PlayertakerComponent', () => {
  let component: PlayertakerComponent;
  let fixture: ComponentFixture<PlayertakerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayertakerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayertakerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
