import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { PlayerService } from '../player.service';

@Component({
  selector: 'app-playertaker',
  templateUrl: './playertaker.component.html',
  styleUrls: ['./playertaker.component.css']
})
export class PlayertakerComponent implements OnInit {

  msg : string;
  playerobj : Player;
  players : Array<Player> =[];
constructor(private playerserv : PlayerService) //dependency injection
{
this.playerobj=new Player();
}


ngOnInit():void
{
 
}

addplayer()
{
  this.players.push(this.playerobj);
 this.playerserv.addPlayerdata(this.playerobj).subscribe(
   (plobj)=> 
    {
      console.log("Played added" + plobj.playername);
     
    }
 ,
 (err)=>
 {
   
     console.log("Error occured" + err);
  

 }) ;

this.playerobj=new Player();

} // addplayer()



}
