import { Component, OnInit } from '@angular/core';
import { Player } from '../player';
import { PlayerService } from '../player.service';

@Component({
  selector: 'app-listview',
  templateUrl: './listview.component.html',
  styleUrls: ['./listview.component.css']
})
export class ListviewComponent implements OnInit 
{

 
  msg : string;
  playerobj : Player;
  players : Array<Player> =[];

  playersindia : Array<Player> =[];
  playerschina: Array<Player> =[];

constructor(private playerserv : PlayerService) //dependency injection
{
this.playerobj=new Player();
}


ngOnInit():void
{
  this.playerserv.getPlayerDetail().subscribe
  (
    (plaarray)=> {
      
      this.filterPlayer(plaarray);


    },
    (err)=>{}
  );
 
}

filterPlayer( data : Array<Player>)
{
  this.playersindia= data.filter (  plaobj => plaobj.country==="India");
  this.playerschina= data.filter ( plaobj => plaobj.country==="China");
}


  getallplayers()
{

  // this.playerserv.getPlayerDetail().subscribe
  // (
  //   (plaarray)=> {
      
  //     this.players=plaarray;

  //   }
  // );
}
  }
  


