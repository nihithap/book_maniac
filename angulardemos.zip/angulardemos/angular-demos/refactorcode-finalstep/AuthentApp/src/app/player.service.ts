import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { Player } from './player';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticateService } from './authenticate.service';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

player : Player;
players : Array<Player>=[];
playersubject : BehaviorSubject<Array<Player>>;

constructor(private httpclient : HttpClient,private authservice : AuthenticateService)
{
this.player=new Player();
this.playersubject=new BehaviorSubject([]);

}

fetchPlayerfromServer()
{
  let tok=this.authservice.getbearerToken();
return this.httpclient.get<Array<Player>>('http://localhost:3000/api/v1/players',
{
  headers : new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
).subscribe ( res=>
  {
    this.players=res;
    this.playersubject.next(this.players);
  },
  (err)=>{this.playersubject.error(err);}
  );

}
  addPlayerdata(playerobj : Player) : Observable<Player>
  {
    let tok=this.authservice.getbearerToken();
 return this.httpclient.post<Player>('http://localhost:3000/api/v1/players',playerobj,
 {
  headers : new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
 ).do( (nplayer) => 
  {
    this.players.push(nplayer);
    this.playersubject.next(this.players);
  } )

  }

  getPlayerDetail() : BehaviorSubject<Array<Player>>
  {
  return this.playersubject;
  }

editPlayer(playtoupd : Player ) : Observable<Player>
{
  let tok=this.authservice.getbearerToken();
 return this.httpclient.put<Player>(`http://localhost:3000/api/v1/players/${playtoupd.id}`,
 playtoupd,
 {
  headers : new HttpHeaders().set('Authorization',`Bearer ${tok}`)
   }
 ).do ( 
   (updatedplayer)=>
   {
 const playerfound= this.players.find ( playobj=> playobj.id == updatedplayer.id );
 Object.assign(playerfound,updatedplayer);


 this.playersubject.next(this.players);
   }
 );

}

getPlayerbyId(playerid) : Player{
let found= this.players.find ( plaobj => plaobj.id == playerid);
//return found;
return (Object.assign({},found));
}

  
}
