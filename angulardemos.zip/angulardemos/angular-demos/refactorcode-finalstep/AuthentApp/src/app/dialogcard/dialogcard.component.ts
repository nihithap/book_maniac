import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Player } from '../player';
import { PlayerService } from '../player.service';
import { MyrouteService } from '../myroute.service';

@Component({
  selector: 'app-dialogcard',
  templateUrl: './dialogcard.component.html',
  styleUrls: ['./dialogcard.component.css']
})
export class DialogcardComponent implements OnInit,OnDestroy {
playid :string;
playerobj : Player;

  constructor(private mydialog : MatDialogRef<DialogcardComponent>,
    private playserv : PlayerService,
    private route : MyrouteService,
    @Inject(MAT_DIALOG_DATA) private data:any )
    { }

  ngOnInit(): void {
    this.playid=this.data.playerid;
this.playerobj=this.playserv.getPlayerbyId(this.playid);

  }

  close()
  {
    this.mydialog.close();
  }

  update()
  {
    this.playserv.editPlayer(this.playerobj).subscribe(

      updplayer=>
      {
        this.mydialog.close();
      },
      (err)=>{console.log(err)}
    )
  }

  ngOnDestroy():void{
    this.route.routeback();
  }
}
