import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogcardComponent } from './dialogcard.component';

describe('DialogcardComponent', () => {
  let component: DialogcardComponent;
  let fixture: ComponentFixture<DialogcardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogcardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
